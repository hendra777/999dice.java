﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dice.Sample.Bot
{
    public static class StringExtensions
    {
        public static bool IsNullOrWhiteSpace(this string s)
        {
            if (string.IsNullOrEmpty(s))
                return true;
            return s.Trim().Equals(string.Empty);
        }
    }
}
