﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Dice.Sample.Bot
{
    public static class Settings
    {
        // Change to your own key.
        // Your own key is linked to your account, so any new accounts created from within your software
        // will be credited as referrals by you.
        public const string ApiKey = "CA3D5DCBAA8542B690086209B271B272";

        // Change at least "Dice.Sample.Bot"
        public static readonly string DataFileDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Dice.Sample.Bot");

        static Settings()
        {
            Directory.CreateDirectory(DataFileDirectory);
        }
    }
}
